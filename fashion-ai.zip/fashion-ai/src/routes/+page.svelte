<script>
  import { goto } from '$app/navigation';
  let animateOut = false;

  function enterApp() {
    animateOut = true;
    setTimeout(() => {
      goto('/upload');
    }, 1000); // Match with animation duration
  }
</script>

<style>
  .hero-container {
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #000000, #1f1f1f);
    color: white;
    transition: transform 1s ease-in-out;
  }

.hero-content {
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 1rem;
  padding: 2rem;
  opacity: 0;
  transform: translateY(20px);
  animation: fadeInUp 1.2s ease-out forwards;
}

@keyframes fadeInUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}


.hero-row {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 2rem;
}

.hero-description {
  font-size: 1rem;
  color: #ccc;
  margin-top: 1rem;
  max-width: 600px;
}


.hero-description {
  font-size: 1.1rem;
  color: #ccc;
  max-width: 600px;
  margin-top: 1.5rem;
}

  @keyframes fadeInUp {
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }


  .enter-button {
    font-size: 1.2rem;
    padding: 0.8rem 1.5rem;
    background-color: #ffffff10;
    border: 2px solid white;
    border-radius: 8px;
    cursor: pointer;
    color: white;
    transition: background 0.3s;
  }

  .enter-button:hover {
    background-color: white;
    color: black;
    transform: scale(1.05);
    transition: transform 1.0s ease;
  }

  .background-animation {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background:
      radial-gradient(circle, rgba(120,120,120,0.03) 20%, transparent 20%) 0 0,
      radial-gradient(circle, rgba(255,255,255,0.03) 20%, transparent 20%) 50px 50px;
    background-size: 100px 100px;
    animation: scrollBackground 4s linear infinite;
    z-index: 1;
  }

  @keyframes scrollBackground {
    from {
      background-position: 0 0, 50px 50px;
    }
    to {
      background-position: 100px 100px, 150px 150px;
    }
  }


  .zoom-out {
    transform: scale(3);
    opacity: 0;
  }
</style>

<div class="hero-container {animateOut ? 'zoom-out' : ''}">
  <div class="background-animation"></div>

  <div class="hero-content">
    <div class="hero-row">
      <h1>Welcome to <strong>StyleEra</strong></h1>
      <button class="enter-button" on:click={enterApp}>
        Enter
      </button>
    </div>
    <p class="hero-description">
      Discover your unique style through time. Upload your photos and let us guide you through fashion's rich history.
    </p>
  </div>
</div>


<div class="main-container">

  </div>

  <!-- Center: reserved blank -->
  <div class="center-panel">
    <!-- empty for now -->
  </div>


