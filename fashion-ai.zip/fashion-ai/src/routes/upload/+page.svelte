<script>
  import { fade } from 'svelte/transition';
  import { onDestroy } from 'svelte';
  import Chart from 'chart.js/auto';
  import { tick } from 'svelte';

  let showCharts = false;
  let tagChart, eraChart;

  const searchesToGenerate = 1;
  const maxRecommendations = 5;
  const totalTagSamples = 2;

  let files = [];
  let visibleImages = [];
  let isDragging = false;
  let allImagesVisible = false;
  let imageUrls = [];
  let analysisData = null;

  let allDecisionsComplete = false;

  let responses = {}; // Track yes/no per image index

  // Position and drag state for swipe card
  let dragStartX = 0;
  let dragCurrentX = 0;
  let isDraggingCard = false;

  // Threshold in px to count as swipe
  const swipeThreshold = 120;

  let loading = false;
  let showUpload = true;
  let showRecommendations = false;
  let imagesExpanded = true;

  let recommendedImages = [];
  let currentRecIndex = 0;
  let recLoading = false;
  let loadingMessage = "";

  function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

  function createImageUrls(files) {
    imageUrls.forEach(url => URL.revokeObjectURL(url));
    return files.map(file => URL.createObjectURL(file));
  }

  async function animateImages(newFiles) {
    allImagesVisible = false;
    visibleImages = [];
    imageUrls = createImageUrls(newFiles);

    for (let i = 0; i < imageUrls.length; i++) {
      visibleImages = [...visibleImages, imageUrls[i]];
      await new Promise(r => setTimeout(r, 120));
    }

    allImagesVisible = true;
  }

  function handleFiles(selectedFiles) {
    files = [...files, ...Array.from(selectedFiles)];
    animateImages(files);
  }

  function handleDrop(event) {
    event.preventDefault();
    isDragging = false;
    handleFiles(event.dataTransfer.files);
  }

  function handleDragOver(event) {
    event.preventDefault();
    isDragging = true;
  }

  function handleDragLeave() {
    isDragging = false;
  }

  function handleFileInput(event) {
    handleFiles(event.target.files);
  }

  async function analyzeImages() {
    if (files.length === 0) {
      alert('Please upload images before analyzing.');
      return;
    }

    loading = true;
    loadingMessage = "Analyzing data...";

    try {
      const formData = new FormData();
      for (const file of files) {
        formData.append('files', file);
      }

      const response = await fetch('http://4.182.216.250:8000/get_analysis', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error(`Server error: ${response.statusText}`);

      loading = false;
      showUpload = false;
      showCharts = true;

      analysisData = await response.json();

      // Wait for Svelte to render the canvases
      showCharts = true;
      await tick(); // ensure DOM is updated

      // Then draw charts
      drawDistributionCharts(analysisData);

    } catch (error) {
      console.error('Error during analysis:', error);
      alert('Error during analysis. Check console.');
      loading = false;
    }
  }

  function drawDistributionCharts(data) {
  // Clean up previous charts if they exist
  if (tagChart) tagChart.destroy();
  if (eraChart) eraChart.destroy();

  // Sort tags by value descending
  const sortedTags = Object.entries(data.tags).sort((a, b) => b[1] - a[1]);
  const tagLabels = sortedTags.map(([tag]) => tag);
  const tagValues = sortedTags.map(([_, val]) => val);

  const eraLabels = Object.keys(data.eras);
  const eraValues = Object.values(data.eras);

  const maxTagValue = Math.max(...tagValues);
  const maxEraValue = Math.max(...eraValues);

  // Generate a nice color per tag/era
  const tagColors = tagLabels.map((_, i) => `hsl(${(i * 37) % 360}, 70%, 60%)`);
  const eraColors = eraLabels.map((_, i) => `hsl(${(i * 60) % 360}, 70%, 60%)`);

  const tagCtx = document.getElementById('tagChart').getContext('2d');
  const eraCtx = document.getElementById('eraChart').getContext('2d');

  tagChart = new Chart(tagCtx, {
    type: 'bar',
    data: {
      labels: tagLabels,
      datasets: [{
        label: 'Tag Distribution',
        data: tagValues,
        backgroundColor: tagColors,
        hoverBackgroundColor: 'rgba(255,255,255,0.3)',
        borderRadius: 6,
      }]
    },
    options: {
      indexAxis: 'y',
      scales: {
        x: {
          min: 0,
          max: maxTagValue * 1.1,
          ticks: {
            callback: value => `${(value * 100).toFixed(0)}%`
          }
        }
      },
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `${(ctx.raw * 100).toFixed(1)}%`
          }
        }
      }
    }
  });

  eraChart = new Chart(eraCtx, {
    type: 'bar',
    data: {
      labels: eraLabels,
      datasets: [{
        label: 'Era Distribution',
        data: eraValues,
        backgroundColor: eraColors,
        hoverBackgroundColor: 'rgba(255,255,255,0.3)',
        borderRadius: 6,
      }]
    },
    options: {
      scales: {
        y: {
          min: 0,
          max: maxEraValue * 1.1,
          ticks: {
            callback: value => `${(value * 100).toFixed(0)}%`
          }
        }
      },
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => `${(ctx.raw * 100).toFixed(1)}%`
          }
        }
      }
    }
  });
}




  async function proceedToRecommendations() {
    loading = true;
    loadingMessage = "Generating search terms...";

    let allRecommendations = [];

    for (let i = 0; i < searchesToGenerate; i++) {
      const searchRes = await fetch(`http://4.182.216.250:8000/generate_searches?distributions=${encodeURIComponent(analysisData)}&total_samples=${totalTagSamples}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(analysisData),
      });

      if (!searchRes.ok) throw new Error("Search generation error");

      const searchData = await searchRes.json();
      const query = searchData.era + " " + searchData.tags.join(",") + " outfit";
      loadingMessage = `Distribution search: ${query}`;

      const recs = await fetchRecommendations(query);
      if (recs && recs.length) {
        allRecommendations.push(...recs);
      }
    }

    recommendedImages = allRecommendations;
    recommendedImages = shuffleArray(allRecommendations);

    currentRecIndex = 0;
    showCharts = false;
    showRecommendations = true;

    loading = false;
    loadingMessage = "";
  }

  async function fetchRecommendations(searchTerm) {
    recLoading = true;
    try {
      const response = await fetch(`http://4.182.216.250:8000/get_recommendations?search_term=${encodeURIComponent(searchTerm)}&top_n=${maxRecommendations}&scrolls=1`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error(`HTTP error ${response.status}`);

      const data = await response.json();

      recLoading = false;
      currentRecIndex = 0;
      return data.top_images || [];
    } catch (e) {
      recLoading = false;
      return [];
    }
  }

  function showNextImage() {
    currentRecIndex = Math.min(currentRecIndex + 1, recommendedImages.length - 1);
  }

  function showPrevImage() {
    currentRecIndex = Math.max(0, currentRecIndex - 1);
  }

  onDestroy(() => {
    imageUrls.forEach(url => URL.revokeObjectURL(url));
    tagChart?.destroy();
    eraChart?.destroy();
  });


    function pointerDown(event) {
    isDraggingCard = true;
    dragStartX = event.type.startsWith('touch') ? event.touches[0].clientX : event.clientX;
    dragCurrentX = dragStartX;
  }

  function pointerMove(event) {
    if (!isDraggingCard) return;
    dragCurrentX = event.type.startsWith('touch') ? event.touches[0].clientX : event.clientX;
  }

  function pointerUp() {
    if (!isDraggingCard) return;
    const diff = dragCurrentX - dragStartX;

    if (diff > swipeThreshold) {
      // Swiped right → yes
      responses[currentRecIndex] = 'yes';
      nextCard();
    } else if (diff < -swipeThreshold) {
      // Swiped left → no
      responses[currentRecIndex] = 'no';
      nextCard();
    } else {
      // Not enough swipe, reset position
      resetCardPosition();
    }

    isDraggingCard = false;
  }

  function nextCard() {
    // Move to next image or finish
    if (currentRecIndex < recommendedImages.length - 1) {
      currentRecIndex += 1;
    } else {
      // Maybe show summary or disable swiping here
      // For now just stay on last image
    }
    resetCardPosition();

    checkIfAllDecided();

  }

  // Card transform style reactive
  $: cardTranslateX = isDraggingCard ? dragCurrentX - dragStartX : 0;

  // For smooth transition when resetting position
  let isResetting = false;
  function resetCardPosition() {
    isResetting = true;
    setTimeout(() => {
      isResetting = false;
    }, 300);
  }
  function checkIfAllDecided() {
  if (Object.keys(responses).length === recommendedImages.length) {
    handleAllDecided();
  }
}

async function handleAllDecided() {
  // Gather accepted and rejected images in order
  const accepted = [];
  const rejected = [];
  for (let i = 0; i < recommendedImages.length; i++) {
    if (responses[i] === 'yes') {
      accepted.push(recommendedImages[i]);
    } else if (responses[i] === 'no') {
      rejected.push(recommendedImages[i]);
    }
  }

  loading = true;
  loadingMessage = "Updating your style profile...";

  console.log(analysisData)

  try {
    const payload = {
      current_distribution: analysisData,
      accepted_images: accepted,
      rejected_images: rejected
    };

    const response = await fetch('http://4.182.216.250:8000/update_distribution', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error('Network response was not ok');

    const oldDistribution = analysisData;
    const newDistribution = await response.json();
    analysisData = newDistribution;

    // Hide card game and show charts
    allDecisionsComplete = true;
    showRecommendations = false;
    showCharts = true;

    await tick();
    drawComparisonCharts(oldDistribution, newDistribution);

  } catch (error) {
    console.error('Error updating distribution:', error);
  } finally {
    loading = false;
  }
}


function drawComparisonCharts(oldData, newData) {
  // Clean up previous charts if they exist
  if (tagChart) tagChart.destroy();
  if (eraChart) eraChart.destroy();

  // Sort tags by new value descending
  const sortedTags = Object.entries(newData.tags).sort((a, b) => b[1] - a[1]);
  const tagLabels = sortedTags.map(([tag]) => tag);

  // Prepare tag datasets
  const tagDatasets = [
    {
      label: 'Old Distribution',
      data: tagLabels.map(tag => oldData.tags[tag] || 0),
      backgroundColor: 'rgba(255, 99, 132, 0.5)',
      borderColor: 'rgba(255, 99, 132, 1)',
      borderWidth: 1
    },
    {
      label: 'New Distribution',
      data: tagLabels.map(tag => newData.tags[tag] || 0),
      backgroundColor: 'rgba(54, 162, 235, 0.5)',
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1
    }
  ];

  // Era datasets
  const eraLabels = Object.keys(newData.eras);
  const eraDatasets = [
    {
      label: 'Old Distribution',
      data: eraLabels.map(era => oldData.eras[era] || 0),
      backgroundColor: 'rgba(255, 99, 132, 0.5)',
      borderColor: 'rgba(255, 99, 132, 1)',
      borderWidth: 1
    },
    {
      label: 'New Distribution',
      data: eraLabels.map(era => newData.eras[era] || 0),
      backgroundColor: 'rgba(54, 162, 235, 0.5)',
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1
    }
  ];

  // Get max values for scaling
  const maxTagValue = Math.max(
    ...tagDatasets[0].data,
    ...tagDatasets[1].data
  );

  const maxEraValue = Math.max(
    ...eraDatasets[0].data,
    ...eraDatasets[1].data
  );

  // Create tag comparison chart
  const tagCtx = document.getElementById('tagChart').getContext('2d');
  tagChart = new Chart(tagCtx, {
    type: 'bar',
    data: {
      labels: tagLabels,
      datasets: tagDatasets
    },
    options: {
      indexAxis: 'y',
      scales: {
        x: {
          min: 0,
          max: maxTagValue * 1.1,
          ticks: {
            callback: value => `${(value * 100).toFixed(0)}%`
          }
        }
      },
      responsive: true,
      plugins: {
        tooltip: {
          callbacks: {
            label: ctx => {
              const datasetLabel = ctx.dataset.label;
              const value = (ctx.raw * 100).toFixed(1);
              const change = ctx.datasetIndex === 1
                ? oldData.tags[tagLabels[ctx.dataIndex]]
                  ? ` (${((ctx.raw - oldData.tags[tagLabels[ctx.dataIndex]]) * 100).toFixed(1)}%)`
                  : ' (new)'
                : '';
              return `${datasetLabel}: ${value}%${change}`;
            }
          }
        }
      }
    }
  });

  // Create era comparison chart
  const eraCtx = document.getElementById('eraChart').getContext('2d');
  eraChart = new Chart(eraCtx, {
    type: 'bar',
    data: {
      labels: eraLabels,
      datasets: eraDatasets
    },
    options: {
      scales: {
        y: {
          min: 0,
          max: maxEraValue * 1.1,
          ticks: {
            callback: value => `${(value * 100).toFixed(0)}%`
          }
        }
      },
      responsive: true,
      plugins: {
        tooltip: {
          callbacks: {
            label: ctx => {
              const datasetLabel = ctx.dataset.label;
              const value = (ctx.raw * 100).toFixed(1);
              const change = ctx.datasetIndex === 1
                ? oldData.eras[eraLabels[ctx.dataIndex]]
                  ? ` (${((ctx.raw - oldData.eras[eraLabels[ctx.dataIndex]]) * 100).toFixed(1)}%)`
                  : ' (new)'
                : '';
              return `${datasetLabel}: ${value}%${change}`;
            }
          }
        }
      }
    }
  });
}


</script>


<style>
  .swipe-card-container {
    position: relative;
    width: 60vw;
    max-width: 600px;
    height: 60vh;
    margin: 0 auto;
    perspective: 1000px;
    user-select: none;
  }

  .swipe-card {
    width: 100%;
    height: 100%;
    border-radius: 10px;
    box-shadow: 0 0 20px #00aced;
    background-color: #111;
    background-size: cover;
    background-position: center;
    cursor: grab;
    touch-action: pan-y;
    position: absolute;
    top: 0;
    left: 0;
    will-change: transform;
    transition: transform 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .swipe-card.grabbing {
    cursor: grabbing;
    transition: none !important;
  }

  .overlay-label {
    position: absolute;
    top: 20px;
    font-size: 3rem;
    font-weight: 900;
    padding: 0.2em 0.8em;
    border-radius: 8px;
    color: white;
    user-select: none;
    pointer-events: none;
    opacity: 0.8;
    text-shadow: 0 0 10px black;
    transform: rotate(-15deg);
  }

  .overlay-yes {
    left: 20px;
    background-color: #28a745; /* green */
  }

  .overlay-no {
    right: 20px;
    background-color: #dc3545; /* red */
    transform: rotate(15deg);
  }

  /* Keep your styles unchanged */
.upload-container {
  min-height: 100vh;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(0,0,0,0.7));
  backdrop-filter: blur(10px);
  color: white;
  padding: 2rem;
  animation: fadeIn 2s ease-in-out;
}

  .main-container {
  display: flex;
  height: 100vh;
  padding: 2rem;
  gap: 1.5rem;
  background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(0,0,0,0.6));
  color: white;
  overflow: hidden;
}

.left-panel {
  flex: 0 0 250px;
  background: rgba(255,255,255,0.07);
  border-radius: 12px;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  user-select: none;
  box-shadow: 0 0 15px rgba(0,0,0,0.3);
  backdrop-filter: blur(10px);
}

.left-panel button.collapse-btn {
  background: #00aced;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  color: white;
  cursor: pointer;
  font-weight: 600;
  transition: background-color 0.3s;
}

.left-panel button.collapse-btn:hover {
  background: #0086c9;
}

.images-list {
  overflow-y: auto;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  gap: 0.7rem;
}

.images-list img {
  width: 100%;
  border-radius: 8px;
  object-fit: cover;
  border: 2px solid #00aced;
}

.center-panel {
  flex: 1;
  background: transparent; /* reserved space */
  border-radius: 12px;
  /* optional: add border or subtle pattern if you want */
}

.right-panel {
  flex: 0 0 450px;
  background: rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 1rem;
  box-shadow: 0 0 15px rgba(0,0,0,0.3);
  backdrop-filter: blur(12px);
  display: flex;
  flex-direction: column;
  gap: 1rem;
  overflow-y: auto;
}

.analytics-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2rem;
  margin: 2rem auto;
  width: 100%;
  max-width: 800px;
  padding: 0 1rem;
}

.chart-card {
  background-color: rgba(255, 255, 255, 0.03);
  padding: 1rem;
  border-radius: 12px;
  width: 100%;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.chart-card h3 {
  text-align: center;
  margin-bottom: 1rem;
  color: #ddd;
}


.charts-container {
  width: 100%;
  max-width: 600px;
  margin: 2rem auto;
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.charts-wrapper {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  gap: 2rem;
  flex-wrap: wrap;
  margin-top: 2rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 900px; /* limit total width */
}



.button-wrapper {
  display: flex;
  justify-content: center;
  margin-top: 2rem;
}


.chart-box {
  width: 600px; /* was 400px */
  max-width: 100%;
  height: 320px;
  background: rgba(255,255,255,0.05);
  padding: 1rem;
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0,0,0,0.4);
}





.chart-box canvas {
  width: 100% !important;
  height: 100% !important;
}


/* Loading overlay */
.loading-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  color: white;
  font-size: 1.2rem;
  user-select: none;
  gap: 1rem;
  font-weight: 600;
}

.spinner {
  width: 48px;
  height: 48px;
  border: 6px solid #ccc;
  border-top-color: #00aced;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}



.background-dots {
  position: absolute;
  width: 200%;
  height: 200%;
  top: -50%;
  left: -50%;
  background: radial-gradient(circle, rgba(120,120,120,0.03) 20%, transparent 20%),
              radial-gradient(circle, rgba(255,255,255,0.03) 20%, transparent 20%);
  background-position: 0 0, 50px 50px;
  background-size: 100px 100px;
  animation: moveBackground 60s linear infinite;
  z-index: 0;
  pointer-events: none;
  filter: brightness(0.7);
}



  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .drop-zone {
    border: 2px dashed #ccc;
    border-radius: 10px;
    padding: 2rem;
    text-align: center;
    transition: background-color 0.3s, border-color 0.3s;
    width: 100%;
    max-width: 600px;
    margin-bottom: 2rem;
    background-color: rgba(255, 255, 255, 0.05);
  }

  .drop-zone.dragging {
    background-color: rgba(255, 255, 255, 0.1);
    border-color: #fff;
  }

  .drop-zone input {
    display: none;
  }

  .drop-zone label {
    cursor: pointer;
    color: #00aced;
    text-decoration: underline;
  }

  .preview {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    justify-content: center;
  }

  .preview img {
    width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
    border: 2px solid #fff;
  }

  .analyze-button {
    margin-top: 2rem;
    padding: 0.8rem 2rem;
    font-size: 1.1rem;
    border: 2px;
    background: #ffffff20;
    color: white;
    border: 2px solid white;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s, opacity 0.6s;
    opacity: 0;
  }
  .analyze-button.visible {
    opacity: 1;
  }

  .analyze-button:hover {
    background: white;
    color: black;
  }
</style>

{#if showUpload}
  <!-- Upload Section -->
  <div class="upload-container">
    <div
      class="drop-zone {isDragging ? 'dragging' : ''}"
      on:drop={handleDrop}
      on:dragover={handleDragOver}
      on:dragleave={handleDragLeave}
    >
      <p>Drag and drop your outfit images here</p>
      <p>or</p>
      <label for="fileInput">Browse Files</label>
      <input
        id="fileInput"
        type="file"
        multiple
        accept="image/*"
        on:change={handleFileInput}
      />
    </div>

    {#if visibleImages.length > 0}
      <div class="preview">
        {#each visibleImages as url (url)}
          <img src={url} alt="Uploaded Image Preview" in:fade={{ duration: 400 }} />
        {/each}
      </div>
    {/if}

    {#if allImagesVisible && visibleImages.length > 0}
      <button class="analyze-button visible" on:click={analyzeImages} in:fade={{ duration: 1000 }}>
        Analyze 🤖
      </button>
    {/if}
  </div>
{:else if showRecommendations && recommendedImages.length > 0}
  <!-- Card Game Section -->
  <div class="main-container card-game-view">
    <div
      class="swipe-card-container"
      on:pointerdown={pointerDown}
      on:pointermove={pointerMove}
      on:pointerup={pointerUp}
      on:pointercancel={pointerUp}
      on:touchstart={pointerDown}
      on:touchmove={pointerMove}
      on:touchend={pointerUp}
      on:touchcancel={pointerUp}
    >
      <div
        class="swipe-card {isDraggingCard ? 'grabbing' : ''}"
        style="background-image: url('{recommendedImages[currentRecIndex]}'); transform: translateX({cardTranslateX}px) rotate({cardTranslateX / 20}deg); transition: {isResetting ? 'transform 0.3s ease' : 'none'};"
      >
        {#if cardTranslateX > 50}
          <div class="overlay-label overlay-yes">YES</div>
        {:else if cardTranslateX < -50}
          <div class="overlay-label overlay-no">NO</div>
        {/if}
      </div>
    </div>

    <div class="card-status">
      Image {currentRecIndex + 1} of {recommendedImages.length} &nbsp;|&nbsp;
      Answer: {responses[currentRecIndex] ?? 'undecided'}
    </div>
  </div>
{:else if showCharts}
  <!-- Charts Section -->
  <div class="main-container charts-view">
    <div class="charts-wrapper">
      <div class="chart-box">
        <h3>Tag Distribution</h3>
        <canvas id="tagChart"></canvas>
      </div>
      <div class="chart-box">
        <h3>Era Distribution</h3>
        <canvas id="eraChart"></canvas>
      </div>
    </div>

    {#if allDecisionsComplete}
      <div class="button-wrapper">
        <button on:click={resetAndGetNewRecommendations} class="analyze-button visible">
          Get New Recommendations
        </button>
      </div>
    {:else}
      <div class="button-wrapper">
        <button on:click={proceedToRecommendations} class="analyze-button visible">
          See Recommendations
        </button>
      </div>
    {/if}
  </div>
{/if}

{#if loading}
  <div class="loading-overlay">
    <div class="spinner"></div>
    <div class="tooltip">{loadingMessage}</div>
  </div>
{/if}